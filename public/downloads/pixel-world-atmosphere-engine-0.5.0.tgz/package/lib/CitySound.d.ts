/** Independent exterior sound bus. Radio and room switches never pass through it. */
export declare class CitySound {
    private ctx;
    private filter;
    private gain;
    private sources;
    private nodes;
    private timer;
    private enabled;
    private volume;
    private nextCar;
    private nextPolice;
    private disposed;
    private noise;
    constructor(ctx: AudioContext, destination: AudioNode);
    set(enabled: boolean, volume: number, closed: number): void;
    private schedule;
    private event;
    private track;
    flyby(): void;
    police(): void;
    dispose(): void;
}
