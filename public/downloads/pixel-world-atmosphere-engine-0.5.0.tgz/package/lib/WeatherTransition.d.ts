import type { AtmosphereParameters, ParameterPatch } from './types';
/** Seed and pass depths stay fixed to avoid resetting moving clouds and wet glass. */
export declare class WeatherTransition {
    readonly seconds: number;
    private from;
    private to;
    private elapsed;
    constructor(from: AtmosphereParameters, target: ParameterPatch, seconds?: number);
    get done(): boolean;
    update(dt: number): AtmosphereParameters;
}
