import { AtmosphereEngine } from './AtmosphereEngine';
import type { SoundscapeProfile, LandscapeSound } from './LandscapeAudio';
import type { EngineOptions, ParameterPatch, LayerPlacement } from './types';
export interface PanoramaView {
    name: string;
    layers: Record<string, LayerPlacement>;
}
export interface PanoramaExperienceOptions extends EngineOptions {
    storageKey?: string;
    hotkeys?: boolean;
    transitionSeconds?: number;
    views?: readonly PanoramaView[];
    soundscape?: SoundscapeProfile;
    sounds?: readonly LandscapeSound[];
    fillScreen?: boolean;
    onFrame?: (engine: AtmosphereEngine, dt: number) => void;
}
/** Owns the animation loop. Use engine directly for advanced integration. */
export declare class PanoramaExperience {
    private options;
    private stage;
    readonly engine: AtmosphereEngine;
    readonly element: HTMLElement;
    private transition?;
    private flight?;
    private placements;
    private audio?;
    private sound;
    private volume;
    private shutter;
    private index;
    private raf;
    private previous;
    private disposed;
    private panel;
    private status;
    private observer;
    private constructor();
    static create(options: PanoramaExperienceOptions): Promise<PanoramaExperience>;
    setWeather(patch: ParameterPatch, seconds?: number): void;
    randomWeather(): {
        kind: import("./randomWeather").WeatherKind;
        name: string;
        parameters: import("./types").AtmosphereParameters;
    };
    changeView(direction: number): void;
    setSound(enabled: boolean): Promise<void>;
    private onKey;
    private fullscreen;
    private fit;
    private frame;
    private persist;
    getParameters(): import("./types").AtmosphereParameters;
    dispose(): void;
}
