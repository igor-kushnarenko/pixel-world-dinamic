export type SoundscapeProfile = 'city' | 'forest' | 'coast' | 'quiet';
export interface LandscapeSound {
    url: string;
    volume?: number;
    loop?: boolean;
}
/** Create/resume only from an explicit user gesture. URL tracks belong to the host. */
export declare class LandscapeAudio {
    readonly profile: SoundscapeProfile;
    private ctx;
    private gain;
    private filter;
    private bed;
    private rain;
    private noise;
    private city?;
    private tracks;
    private trackSources;
    private disposed;
    constructor(profile?: SoundscapeProfile, sounds?: readonly LandscapeSound[]);
    resume(): Promise<void>;
    set(enabled: boolean, volume: number, rain: number, closed: number): void;
    dispose(): void;
}
