export interface Body {
    x: number;
    y: number;
    vy: number;
    width: number;
    height: number;
}
export declare const SILL_BACK = 775, SILL_FRONT = 835;
/** The sill widens towards the viewer; its rear edge follows the window opening. */
export declare function sillBounds(y: number, width: number): {
    left: number;
    right: number;
};
export declare function dragPosition(x: number, y: number, width: number, height: number): {
    x: number;
    y: number;
};
export declare function restingPosition(body: Body): {
    vy: number;
    x: number;
    y: number;
    width: number;
    height: number;
};
/** Release over the window drops to the back; release on the tabletop preserves depth. */
export declare function fallStep(body: Body, dt: number): Body;
/** Upright 2.5D bodies: depth lanes, horizontal impulses and fixed substeps. */
export interface SillGeometry {
    back: number;
    front: number;
    backLeft: number;
    backRight: number;
    frontLeft: number;
    frontRight: number;
}
export declare class SillPhysics {
    private geometry;
    constructor(geometry?: SillGeometry);
    private bounds;
    private drag;
    private objects;
    add(body: Body, mass: number): {
        readonly body: Body;
        begin: (now: number) => void;
        drag: (x: number, y: number, now: number) => void;
        release: (now: number, cancel?: boolean) => void;
        step: (dt: number) => Body;
        readonly sleeping: boolean;
    };
    private collide;
}
export declare const roomPhysics: SillPhysics;
